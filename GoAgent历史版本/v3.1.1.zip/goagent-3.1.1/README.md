DON'T PANIC
[![status](https://sourcegraph.com/api/repos/github.com/goagent/goagent/badges/status.png)](https://sourcegraph.com/github.com/goagent/goagent)
[![authors](https://sourcegraph.com/api/repos/github.com/goagent/goagent/badges/authors.png)](https://sourcegraph.com/github.com/goagent/goagent)
[![top func](https://sourcegraph.com/api/repos/github.com/goagent/goagent/badges/top-func.png)](https://sourcegraph.com/github.com/goagent/goagent)
[![funcs](https://sourcegraph.com/api/repos/github.com/goagent/goagent/badges/funcs.png)](https://sourcegraph.com/github.com/goagent/goagent)
[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/goagent/goagent/trend.png)](https://bitdeli.com/free "Bitdeli Badge")  
